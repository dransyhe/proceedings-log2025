# Virtual Nodes Go Temporal


This is the implementation of our paper "Virtual Nodes go Temporal". We propose to add Virtual Nodes to a TGN to enhance its capacity to propagate information within the graph after an event occurance.

## Code
The code is based on the original TGB Implementation. We adapted the implementation to take into account the addition of virtual nodes. Therefore the requirements for to run the code:

    1. Having the TGB implementation
    2. PyTorch Geometric
    3. NetworkX

## Requirements
The user should start by downloading TGB and the required requirements. We refer the users to the installation guidelines on https://tgb.complexdatalab.com/.

Note that since we also add some requirements and args, the user should also substitute the "utils.py" in TGB/tgb/utils folder. Otherwise, you can choose to enter the values manually. 


## Usage
To run our k-TVNs for the TGBL-Wiki with the default parameters (also used in the main paper):
```python
python main_vn.py
```
---

For any additional information, please refer to our paper.
