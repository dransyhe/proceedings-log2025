This is the code for paper "Heuristic Methods are Good Teachers to Distill MLPs for Graph Link Prediction"

main directory src files include:

Training teachers and generate gudance: HeaRT/benchmarking/exist\_setting\_small/main\_heuristic\_xxxx.py, HeaRT/benchmarking/exist\_setting\_small/main\_gnn\_xxxx.py, HeaRT/benchmarking/exist\_setting\_ogb/main\_heuristic\_xxxx.py, HeaRT/benchmarking/exist\_setting\_ogb/main\_gnn\_xxxx.py

Distill MLPs: linkless-link-prediction/src/heart\_distill\_grid\_search.py

Ensemble Heuristic-Distilled MLPs: linkless-link-prediction/src/ensemble\_distilled\_mlp.py

The required dependency is the union of the dependency of HeaRT and linkless-link-prediction
