#!/bin/bash
ts_quantiles="0.5 0.6 0.7 0.8 0.9"
for quantile in $ts_quantiles; do
	echo "Running command with ts_quantile=$quantile"
#	python train_teacher_gnn.py --datasets=amazon-Video_Games_5 --encoder=sage --transductive=transductive --ts_quantile=$quantile --num_layers=6 --device=7 --lr=0.001 --runs=1 --dropout=0
#	python main.py --datasets=amazon-Video_Games_5 --KD_RM=0 --LLP_D=1 --KD_LM=0 --LLP_R=1 --True_label=1 --dropout=0.0 --encoder=sage  --hops=6 --lr=0.0001 --margin=0.05 --ns_rate=3 --num_layers=4 --ps_method=nb --rw_step=2 --transductive=transductive --device=7 --runs=1 --ts_quantile=$quantile
#	python -u -W ignore train_teacher_gnn.py --datasets=tgbl-wiki --encoder=sage --runs=1 --transductive=transductive --ts_quantile=$quantile --num_layers=6 --device=4 --dropout=0
	python -u -W ignore main.py --datasets=tgbl-wiki --KD_RM=0 --LLP_D=0.001 --KD_LM=0 --LLP_R=1 --encoder=sage --device=4 --ts_quantile=$quantile --hop=2 --runs=1 --dropout=0
	python -u -W ignore train_teacher_gnn.py --datasets=tgbl-review --encoder=sage --runs=1 --transductive=transductive --ts_quantile=$quantile --num_layers=6 --device=7 --patience=10 --dropout=0 --lr=1e-3
#	python -u -W ignore main.py --datasets=tgbl-review  --KD_RM=0 --LLP_D=1 --KD_LM=0 --LLP_R=1 --dropout=0.0 --encoder=sage --device=7 --ts_quantile=$quantile --hops=3 --lr=0.001 --runs=1 --patience=10 --dropout=0 --lr=1e-4 
#	python train_teacher_gnn.py --datasets=tgbl-coin --encoder=sage --runs=1 --transductive=transductive --ts_quantile=$quantile --num_layers=6 --device=2
#	python main.py --datasets=tgbl-coin  --KD_RM=0 --LLP_D=1 --KD_LM=0 --LLP_R=1 --dropout=0.0 --encoder=sage --device=2 --ts_quantile=$quantile --hops=3 --lr=0.00003 --runs=1
#	python train_teacher_gnn.py --datasets=tgbl-comment --encoder=sage --runs=1 --transductive=transductive --ts_quantile=$quantile --num_layers=6 --device=3
#	python main.py --datasets=tgbl-comment  --KD_RM=0 --LLP_D=1 --KD_LM=0 --LLP_R=1 --dropout=0.0 --encoder=sage --device=3 --ts_quantile=0.5 --hops=3 --lr=0.00003 --runs=1

done
