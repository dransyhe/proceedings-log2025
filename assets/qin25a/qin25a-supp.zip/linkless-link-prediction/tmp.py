import torch
from torch_cluster import random_walk

# Define the graph structure using edge indices
row = torch.tensor([0, 1, 1, 1, 2, 2, 3, 3, 4, 4])
col = torch.tensor([1, 0, 2, 3, 1, 4, 1, 4, 2, 3])

# Define the starting nodes for the random walks
start = torch.tensor([0, 1, 2, 3, 4])

# Generate random walks with a walk length of 3
walk = random_walk(row, col, start, walk_length=3)

print(walk)
