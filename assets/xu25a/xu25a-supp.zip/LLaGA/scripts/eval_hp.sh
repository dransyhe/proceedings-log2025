#!/bin/bash

CUDA_VISIBLE_DEVICES=2 bash scripts/eval.sh &
CUDA_VISIBLE_DEVICES=3 bash scripts/eval1.sh &
# CUDA_VISIBLE_DEVICES=4 bash scripts/eval2.sh &
# CUDA_VISIBLE_DEVICES=5 bash scripts/eval3.sh &
wait