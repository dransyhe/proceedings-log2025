#!/bin/bash

for dir in  "roman_empire" #"amazon_ratings" #"school.13" "citeseer.5" "cora.5" "pubmed" "roman_empire" "amazon_ratings" 
do
    if [ ${dir} = "cora.5" ]; then
        dataset="cora"
        emb="simteg"
    elif [ ${dir} = "pubmed" ]; then
        dataset="pubmed"
        emb="simteg"
    elif [ ${dir} = 'roman_empire' ]; then
        dataset="roman_empire"
        emb="vicuna"
    elif [ ${dir} = 'amazon_ratings' ]; then
        dataset="amazon_ratings"
        emb="vicuna"
    elif [ ${dir} = 'school.13' ]; then
        dataset="school"
        emb="llmicl_primary"
    elif [ ${dir} = 'citeseer.5' ]; then
        dataset="citeseer"
        emb="llmicl_primary"
    fi
    for adapter in gin
    do
        for seed in 42 3407 114514
        do
            model_path=/data/haotian/LLaGA/checkpoints/${dir}/llaga-vicuna-7b-${emb}-2-${adapter}-1-projector_nc_seed_${seed}
            model_base="lmsys/vicuna-7b-v1.5-16k" #meta-llama/Llama-2-7b-hf
            mode="v1" # use 'llaga_llama_2' for llama and "v1" for others
            dataset=${dataset} #test dataset
            task="nc" #test task
            emb=${emb}
            use_hop=1
            sample_size=4
            template="anti-ND" # or ND
            output_path="./outputs/"
            answers_file=./outputs/${adapter}/nc/${dataset}-1-seed-${seed}.json

            # python eval/eval_pretrain_pyg.py \
            # --model_path ${model_path} \
            # --model_base ${model_base} \
            # --conv_mode  ${mode} \
            # --dataset ${dataset} \
            # --pretrained_embedding_type ${emb} \
            # --use_hop ${use_hop} \
            # --sample_neighbor_size ${sample_size} \
            # --answers_file ${answers_file} \
            # --task ${task} \
            # --cache_dir /data/haotian/.cache \
            # --template ${template}

            # wait

            echo -e Test_${dataset}_with_${adapter}_at_seed_${seed}

            python eval/eval_res.py --dataset ${dataset} --task ${task}  --res_path ${answers_file}
        done
    done
done