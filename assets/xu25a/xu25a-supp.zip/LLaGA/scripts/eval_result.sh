#!/bin/bash

for dir in "cora.8" 'arxiv'
do
    if [ ${dir} = "cora.8" ]; then
        dataset="cora"
        emb="simteg"
    elif [ ${dir} = "arxiv" ]; then
        dataset="arxiv"
        emb="simteg"
    elif [ ${dir} = 'roman_empire.5' ]; then
        dataset="roman_empire"
        emb="vicuna"
    elif [ ${dir} = 'amazon_ratings.5' ]; then
        dataset="amazon_ratings"
        emb="vicuna"
    fi
    for adapter in linear gcn gat gin
    do
        model_path=/data/haotian/LLaGA/checkpoints/${dir}/llaga-vicuna-7b-${emb}-2-4-${adapter}-1-projector_nc
        model_base="lmsys/vicuna-7b-v1.5-16k" #meta-llama/Llama-2-7b-hf
        mode="v1" # use 'llaga_llama_2' for llama and "v1" for others
        dataset=${dataset} #test dataset
        task="nc" #test task
        emb=${emb}
        use_hop=1
        sample_size=4
        template="anti-ND" # or ND
        output_path="./outputs/"
        answers_file=./outputs/${adapter}/nc/${dataset}-1.json

        echo -e Test_${dataset}_with_${adapter}

        python eval/eval_res.py --dataset ${dataset} --task ${task}  --res_path ${answers_file}

        echo -e "-------------------------------"

        wait

        model_path=/data/haotian/LLaGA/checkpoints/${dir}/llaga-vicuna-7b-${emb}-2-4-${adapter}-1-projector-gdc_nc
        model_base="lmsys/vicuna-7b-v1.5-16k" #meta-llama/Llama-2-7b-hf
        mode="v1" # use 'llaga_llama_2' for llama and "v1" for others
        dataset=${dataset} #test dataset
        task="nc" #test task
        emb=${emb}
        use_hop=1
        sample_size=4
        template="anti-ND" # or ND
        output_path="./outputs/"
        answers_file=./outputs/${adapter}/nc/${dataset}-1-gdc.json

        echo -e Test_${dataset}_with_${adapter}_gdc

        python eval/eval_res.py --dataset ${dataset} --task ${task}  --res_path ${answers_file}

        echo -e "-------------------------------"

        wait

        model_path=/data/haotian/LLaGA/checkpoints/${dir}/llaga-vicuna-7b-${emb}-2-4-${adapter}-1-projector-sdc_nc
        model_base="lmsys/vicuna-7b-v1.5-16k" #meta-llama/Llama-2-7b-hf
        mode="v1" # use 'llaga_llama_2' for llama and "v1" for others
        dataset=${dataset} #test dataset
        task="nc" #test task
        emb=${emb}
        use_hop=1
        sample_size=4
        template="anti-ND" # or ND
        output_path="./outputs/"
        answers_file=./outputs/${adapter}/nc/${dataset}-1-sdc.json

        echo -e Test_${dataset}_with_${adapter}_sdc

        python eval/eval_res.py --dataset ${dataset} --task ${task}  --res_path ${answers_file}

        echo -e "-------------------------------"

        wait

        model_path=/data/haotian/LLaGA/checkpoints/${dir}/llaga-vicuna-7b-${emb}-2-4-${adapter}-1-projector-sgdc_nc
        model_base="lmsys/vicuna-7b-v1.5-16k" #meta-llama/Llama-2-7b-hf
        mode="v1" # use 'llaga_llama_2' for llama and "v1" for others
        dataset=${dataset} #test dataset
        task="nc" #test task
        emb=${emb}
        use_hop=1
        sample_size=4
        template="anti-ND" # or ND
        output_path="./outputs/"
        answers_file=./outputs/${adapter}/nc/${dataset}-1-sgdc.json

        echo -e Test_${dataset}_with_${adapter}_sgdc

        python eval/eval_res.py --dataset ${dataset} --task ${task}  --res_path ${answers_file}

        echo -e "-------------------------------"

        wait
    done
done