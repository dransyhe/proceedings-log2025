#!/bin/bash

CUDA_VISIBLE_DEVICES=1 bash scripts/eval1.sh &
CUDA_VISIBLE_DEVICES=2 bash scripts/eval2.sh &
CUDA_VISIBLE_DEVICES=3 bash scripts/eval3.sh &
CUDA_VISIBLE_DEVICES=4 bash scripts/eval4.sh &
CUDA_VISIBLE_DEVICES=5 bash scripts/eval5.sh &
CUDA_VISIBLE_DEVICES=6 bash scripts/eval6.sh &
wait