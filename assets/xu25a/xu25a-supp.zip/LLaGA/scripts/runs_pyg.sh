#!/bin/bash

# bash scripts/train_deepspeed_pyg.sh vicuna-linear lp  tox21 12 bert-roberta 10
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn lp  tox21 12 bert-roberta 10
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat lp  tox21 12 bert-roberta 10
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin lp  tox21 12 bert-roberta 10
# wait

# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc cora.8 12 simteg 1
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc cora.8 12 simteg 1
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc cora.8 12 simteg 1
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc arxiv 2 simteg 1
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc arxiv 2 simteg 1
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc arxiv 2 simteg 1
# wait
# # bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc cora.8 12 simteg 3
# # wait
# # bash scripts/train_deepspeed_pyg.sh vicuna-gat nc cora.8 12 simteg 3
# # wait
# # bash scripts/train_deepspeed_pyg.sh vicuna-gin nc cora.8 12 simteg 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc arxiv 2 simteg 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc arxiv 2 simteg 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc arxiv 2 simteg 3
# wait
# # bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc cora.8 12 simteg 5
# # wait
# # bash scripts/train_deepspeed_pyg.sh vicuna-gat nc cora.8 12 simteg 5
# # wait
# # bash scripts/train_deepspeed_pyg.sh vicuna-gin nc cora.8 12 simteg 5
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc arxiv 2 simteg 5
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc arxiv 2 simteg 5
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc arxiv 2 simteg 5
# wait


# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc arxiv 2 simteg 1
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc cora.8 12 simteg 1
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc arxiv 2 simteg 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc cora.8 12 simteg 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc arxiv 2 simteg 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc cora.8 12 simteg 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc arxiv 2 simteg 1 sdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc cora.8 12 simteg 1 sdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc arxiv 2 simteg 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc cora.8 12 simteg 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc arxiv 2 simteg 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc cora.8 12 simteg 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc arxiv 2 simteg 1 sdc
# wait 
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc cora.8 12 simteg 1 sdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc amazon_ratings.5 4 vicuna 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc roman_empire.5 2 vicuna 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc amazon_ratings.5 4 vicuna 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc roman_empire.5 2 vicuna 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc amazon_ratings.5 4 vicuna 1 sdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear nc roman_empire.5 2 vicuna 1 sdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc amazon_ratings.5 4 vicuna 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc roman_empire.5 2 vicuna 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc amazon_ratings.5 4 vicuna 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc roman_empire.5 2 vicuna 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc amazon_ratings.5 4 vicuna 1 sdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc roman_empire.5 2 vicuna 1 sdc


# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc arxiv 2 simteg 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc cora.8 12 simteg 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc arxiv 2 simteg 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc cora.8 12 simteg 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc arxiv 2 simteg 1 sdc
# wait 
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc cora.8 12 simteg 1 sdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc arxiv 2 simteg 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc cora.8 12 simteg 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc arxiv 2 simteg 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc cora.8 12 simteg 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc arxiv 2 simteg 1 sdc
# wait 
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc cora.8 12 simteg 1 sdc



# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc amazon_ratings.5 4 vicuna 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc roman_empire.5 2 vicuna 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc amazon_ratings.5 4 vicuna 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc roman_empire.5 2 vicuna 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc amazon_ratings.5 4 vicuna 1 sdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc roman_empire.5 2 vicuna 1 sdc

# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc amazon_ratings.5 4 vicuna 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc roman_empire.5 2 vicuna 1 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc amazon_ratings.5 4 vicuna 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc roman_empire.5 2 vicuna 1 sgdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc amazon_ratings.5 4 vicuna 1 sdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc roman_empire.5 2 vicuna 1 sdc



# bash scripts/train_deepspeed_pyg.sh vicuna-linear hp cora.8 12 simteg 1 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear hp cora.8 12 simteg 1 3 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn hp cora.8 12 simteg 1 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn hp cora.8 12 simteg 1 3 gdc
# wait 
# bash scripts/train_deepspeed_pyg.sh vicuna-gat hp cora.8 12 simteg 1 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat hp cora.8 12 simteg 1 3 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin hp cora.8 12 simteg 1 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin hp cora.8 12 simteg 1 3 gdc
# wait

# bash scripts/train_deepspeed_pyg.sh vicuna-linear hp amazon_ratings.5 4 vicuna 1 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear hp amazon_ratings.5 4 vicuna 1 3 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn hp amazon_ratings.5 4 vicuna 1 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn hp amazon_ratings.5 4 vicuna 1 3 gdc
# wait 
# bash scripts/train_deepspeed_pyg.sh vicuna-gat hp amazon_ratings.5 4 vicuna 1 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat hp amazon_ratings.5 4 vicuna 1 3 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin hp amazon_ratings.5 4 vicuna 1 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin hp amazon_ratings.5 4 vicuna 1 3 gdc
# wait

# bash scripts/train_deepspeed_pyg.sh vicuna-linear hp roman_empire.5 4 vicuna 1 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-linear hp roman_empire.5 4 vicuna 1 3 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn hp roman_empire.5 4 vicuna 1 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn hp roman_empire.5 4 vicuna 1 3 gdc
# wait 
# bash scripts/train_deepspeed_pyg.sh vicuna-gat hp roman_empire.5 4 vicuna 1 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat hp roman_empire.5 4 vicuna 1 3 gdc
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin hp roman_empire.5 4 vicuna 1 3
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin hp roman_empire.5 4 vicuna 1 3 gdc
# wait

# for hop in 1 3 4
# do
#     bash scripts/train_deepspeed_pyg.sh vicuna-linear hp school.15 8 llmicl_primary 1 ${hop}
#     wait
#     bash scripts/train_deepspeed_pyg.sh vicuna-gat hp school.15 8 llmicl_primary 1 ${hop}
#     wait
#     bash scripts/train_deepspeed_pyg.sh vicuna-gcn hp school.15 8 llmicl_primary 1 ${hop}
#     wait
#     bash scripts/train_deepspeed_pyg.sh vicuna-gin hp school.15 8 llmicl_primary 1 ${hop}
#     wait
#     bash scripts/train_deepspeed_pyg.sh vicuna-linear hp cora.5 8 simteg 1 ${hop}
#     wait
#     bash scripts/train_deepspeed_pyg.sh vicuna-gat hp cora.5 8 simteg 1 ${hop}
#     wait
#     bash scripts/train_deepspeed_pyg.sh vicuna-gcn hp cora.5 8 simteg 1 ${hop}
#     wait
#     bash scripts/train_deepspeed_pyg.sh vicuna-gin hp cora.5 8 simteg 1 ${hop}
#     wait
# done


# for adapter in linear gcn gat gin 
# do
#     for nlayer in 1
#     do
#         for seed in 42 3407 114514
#         do
#             bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} nc school.13 4 llmicl_primary ${nlayer} 2 ${seed} gdc
#             wait
#             bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} nc citeseer.5 4 llmicl_primary ${nlayer} 2 ${seed} gdc
#             wait
#             bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} nc cora.5 4 simteg 1 2 ${seed} 
#             # wait
#             bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} nc pubmed 4 simteg 1 2 ${seed} 
#             wait
#             bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} nc roman_empire 4 vicuna 1 2 ${seed} 
#             wait
#             bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} nc amazon_ratings 4 vicuna 1 2 ${seed} 
#             wait
#         done
#     done
# done

for adapter in linear gcn gat gin 
do
    for nlayer in 1
    do
        for seed in 42 3407 114514
        do
            # bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} hp school.13 4 llmicl_primary ${nlayer} 1 ${seed}
            # wait
            # bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} hp citeseer.5 4 llmicl_primary ${nlayer} 1 ${seed}
            # wait
            # bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} hp cora.5 4 simteg 1 1 ${seed} 
            # wait
            # bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} hp pubmed 4 simteg 1 1 ${seed} 
            # wait
            # bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} hp roman_empire 4 vicuna 1 1 ${seed} 
            # wait
            # bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} hp amazon_ratings 4 vicuna 1 1 ${seed} 
            # wait
            # bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} pd bace.12 4 node 1 1 ${seed}
            # wait
            # bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} pd bace.12 4 brief 1 1 ${seed}
            # wait
            # bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} pd bace.12 4 detailed 1 1 ${seed}
            # wait
            # bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} pd hiv.3 4 node 1 1 ${seed}
            # wait
            # bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} pd hiv.3 4 brief 1 1 ${seed}
            # wait
            # bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} pd hiv.3 4 detailed 1 1 ${seed}
            # wait

            bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} pd bbbp.8 4 node 1 1 ${seed}
            wait
            bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} pd bbbp.8 4 brief 1 1 ${seed}
            wait
            bash scripts/train_deepspeed_pyg.sh vicuna-${adapter} pd bbbp.8 4 detailed 1 1 ${seed}
            wait
        done
    done
done
wait
CUDA_VISIBLE_DEVICES=2 bash scripts/eval_pyg_bbbp.sh &
# CUDA_VISIBLE_DEVICES=3 bash scripts/eval_pyg_citeseer.sh &
# CUDA_VISIBLE_DEVICES=4 bash scripts/eval_pyg_cora.sh &
# CUDA_VISIBLE_DEVICES=5 bash scripts/eval_pyg_pubmed.sh &
# CUDA_VISIBLE_DEVICES=6 bash scripts/eval_pyg_roman.sh &
# CUDA_VISIBLE_DEVICES=7 bash scripts/eval_pyg_school.sh &
wait
# bash scripts/eval_transform.sh