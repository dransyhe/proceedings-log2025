#!/bin/bash

CUDA_VISIBLE_DEVICES=3 bash scripts/eval_linear.sh &
CUDA_VISIBLE_DEVICES=4 bash scripts/eval_gcn.sh &
CUDA_VISIBLE_DEVICES=5 bash scripts/eval_gat.sh &
CUDA_VISIBLE_DEVICES=6 bash scripts/eval_gin.sh &
wait