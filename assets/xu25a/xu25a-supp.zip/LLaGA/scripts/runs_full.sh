#!/bin/bash
# bash scripts/train_deepspeed.sh vicuna_SC lp arxiv-pubmed-cora.3 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_SC lp arxiv-pubmed 4 simteg

# bash scripts/train_deepspeed.sh vicuna_anti_ND lp products 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna lp products 4 simteg
# wait

# bash scripts/train_deepspeed.sh vicuna_anti_ND lp arxiv 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna lp arxiv 4 simteg
# wait

# bash scripts/train_deepspeed.sh vicuna_anti_ND lp pubmed.3 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna lp pubmed.3 4 simteg
# wait

# bash scripts/train_deepspeed.sh vicuna_anti_ND lp cora.8 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna lp cora.8 4 simteg
# wait

# bash scripts/train_deepspeed.sh vicuna_anti_ND nc products 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna nc products 4 simteg
# wait

# bash scripts/train_deepspeed.sh vicuna_anti_ND nc arxiv 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna nc arxiv 4 simteg
# wait

# bash scripts/train_deepspeed.sh vicuna_anti_ND nc pubmed.3 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna nc pubmed.3 4 simteg
# wait

# bash scripts/train_deepspeed.sh vicuna_anti_ND nc cora.8 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna nc cora.8 4 simteg
# wait


# bash scripts/train_deepspeed.sh vicuna nc arxiv-pubmed-cora.3 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_anti_ND nc arxiv-pubmed 4 simteg



# bash scripts/train_deepspeed.sh vicuna lp arxiv-pubmed-cora.3 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna lp arxiv-pubmed 4 simteg

# wait
# bash scripts/train_deepspeed.sh vicuna_HN2 lp arxiv 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN2 lp cora.8 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN2 lp pubmed.3 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN2 lp products 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN3 lp arxiv 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN3 lp cora.8 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN3 lp pubmed.3 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN3 lp products 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN4 lp arxiv 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN4 lp cora.8 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN4 lp pubmed.3 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN4 lp products 4 simteg


# bash scripts/train_deepspeed.sh vicuna_HN2 nc arxiv 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN2 nc cora.8 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN2 nc pubmed.3 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN2 nc products 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN3 nc arxiv 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN3 nc cora.8 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN3 nc pubmed.3 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN3 nc products 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN4 nc arxiv 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN4 nc cora.8 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN4 nc pubmed.3 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN4 nc products 4 simteg


# bash scripts/train_deepspeed.sh vicuna_HN0 nc arxiv 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN0 nc cora.8 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN0 nc pubmed.3 4 simteg
# wait
# bash scripts/train_deepspeed.sh vicuna_HN0 nc products 4 simteg

# bash scripts/train_deepspeed.sh vicuna_anti_ND nc roman_empire.5 4 vicuna
# wait
# bash scripts/train_deepspeed.sh vicuna_anti_ND lp roman_empire.5 4 vicuna
# wait
# bash scripts/train_deepspeed.sh vicuna_anti_ND nc amazon_ratings.5 4 vicuna
# wait
# bash scripts/train_deepspeed.sh vicuna_anti_ND lp amazon_ratings.5 4 vicuna
# wait
# bash scripts/train_deepspeed.sh vicuna_HN0 nc roman_empire.5 4 vicuna
# wait
# bash scripts/train_deepspeed.sh vicuna_HN0 nc amazon_ratings.5 4 vicuna
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc roman_empire.5 2 vicuna 1
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc roman_empire.5 2 vicuna 1
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc roman_empire.5 2 vicuna 1
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gcn nc amazon_ratings.5 2 vicuna 1
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gat nc amazon_ratings.5 2 vicuna 1
# wait
# bash scripts/train_deepspeed_pyg.sh vicuna-gin nc amazon_ratings.5 2 vicuna 1
# wait
# for seed in 42 3407 114514
# do
#     bash scripts/train_deepspeed.sh vicuna nc citeseer.5 4 llmicl_primary ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna nc school.13 4 llmicl_primary ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna nc roman_empire 4 vicuna ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna nc amazon_ratings 4 vicuna ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna nc cora.5 4 simteg ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna nc pubmed 4 simteg ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_anti_ND nc citeseer.5 4 llmicl_primary ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_anti_ND nc school.13 4 llmicl_primary ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_anti_ND nc roman_empire 4 vicuna ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_anti_ND nc amazon_ratings 4 vicuna ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_anti_ND nc cora.5 4 simteg ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_anti_ND nc pubmed 4 simteg ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_HN0 nc citeseer.5 4 llmicl_primary ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_HN0 nc school.13 4 llmicl_primary ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_HN0 nc roman_empire 4 vicuna ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_HN0 nc amazon_ratings 4 vicuna ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_HN0 nc cora.5 4 simteg ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_HN0 nc pubmed 4 simteg ${seed}
#     wait
# done

# for seed in 42 3407 114514
# do
#     bash scripts/train_deepspeed.sh vicuna lp citeseer.5 4 llmicl_primary ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna lp school.13 4 llmicl_primary ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna lp roman_empire 4 vicuna ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna lp amazon_ratings 4 vicuna ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna lp cora.5 4 simteg ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna lp pubmed 4 simteg ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_anti_ND lp citeseer.5 4 llmicl_primary ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_anti_ND lp school.13 4 llmicl_primary ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_anti_ND lp roman_empire 4 vicuna ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_anti_ND lp amazon_ratings 4 vicuna ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_anti_ND lp cora.5 4 simteg ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_anti_ND lp pubmed 4 simteg ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_HN0 lp citeseer.5 4 llmicl_primary ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_HN0 lp school.13 4 llmicl_primary ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_HN0 lp roman_empire 4 vicuna ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_HN0 lp amazon_ratings 4 vicuna ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_HN0 lp cora.5 4 simteg ${seed}
#     wait
#     bash scripts/train_deepspeed.sh vicuna_HN0 lp pubmed 4 simteg ${seed}
#     wait
# done

for task in nc lp
do
    for seed in 42 3407 114514
    do
        for model in vicuna
        do
            # bash scripts/train.sh ${model} ${task} cora.5 4 full ${seed}
            # wait
            # bash scripts/train.sh ${model}_anti_ND ${task} cora.5 4 full ${seed}
            # wait
            bash scripts/train.sh ${model}_HN0 ${task} cora.5 4 full ${seed}
            wait
            # bash scripts/train.sh ${model} ${task} school.13 4 full ${seed}
            # wait
            # bash scripts/train.sh ${model}_anti_ND ${task} school.13 4 full ${seed}
            # wait
            bash scripts/train.sh ${model}_HN0 ${task} school.13 4 full ${seed}
            wait
        done
    done
done
# CUDA_VISIBLE_DEVICES=0 bash scripts/eval.sh

# CUDA_VISIBLE_DEVICES=0 bash scripts/eval.sh